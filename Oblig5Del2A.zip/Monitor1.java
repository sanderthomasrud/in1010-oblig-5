import java.util.HashMap;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Lock;


public class Monitor1 extends SubsekvensRegister{
    private static Lock laas = new ReentrantLock(true);

    public static HashMap<String, Subsekvens> lesFraFil(String filnavn) throws FileNotFoundException {
        laas.lock();
        try {
            HashMap<String, Subsekvens> nyHash = new HashMap<>();
            File nyFil = new File(filnavn);
            Scanner sc;
            try {
                sc = new Scanner(nyFil);
            } catch (FileNotFoundException e) {
                throw new FileNotFoundException();
            }

            ArrayList<String> bokstaver = new ArrayList<>();
            ArrayList<String> sekvens = new ArrayList<>();
            String linje;

            while (sc.hasNextLine()) {
                linje = sc.nextLine();

                if (linje.length() < 3) {
                    System.exit(-1);
                }
                String[] biter = linje.split("");
                
                for (String bit : biter) {
                    bokstaver.add(bit);
                }

                while (bokstaver.size() >= 3) {
                    String sek = bokstaver.get(0) + bokstaver.get(1) + bokstaver.get(2);
                    if (!sekvens.contains(sek)) {
                        sekvens.add(sek);
                    }
                    bokstaver.remove(0);
                }

                for (String s : sekvens) {
                    Subsekvens ny = new Subsekvens(s, 1);
                    nyHash.put(s, ny);
                }
                bokstaver.clear();
                sekvens.clear();
            }
            sc.close();
            
            return nyHash;
        } finally {
            laas.unlock();
        }
    }

    @Override
    public void settInn(HashMap<String, Subsekvens> hashmap) {
        laas.lock();
        try {
           register.add(hashmap); 
        } finally {
            laas.unlock();
        }
    }

}
