import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;

public class Oblig5Del2A {
    private static Monitor1 monitor = new Monitor1();
    public static void main(String[] args) throws FileNotFoundException, InterruptedException {
        String path = args[0];
        lagNyttReg(path);
        slaaSammen();

        skrivUtVanligste(monitor);
    }

    private static void lagNyttReg(String path) throws FileNotFoundException, InterruptedException{
        File nyFil = new File(path);
        Scanner sc;
        try {
            sc = new Scanner(nyFil);
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException();
        }
        
        String nyPath = path.replace("metadata.csv", "");
        File fil = new File(nyPath);
        CountDownLatch barriere = new CountDownLatch(fil.list().length - 1);

        String linje;
        path = path.replace("metadata.csv", "");

        while (sc.hasNextLine()) {
            linje = sc.nextLine();

            Runnable lesetrad = new LeseTrad(path + linje, monitor, barriere);
            Thread trad = new Thread(lesetrad);
            trad.start();          
        }

        barriere.await();

        sc.close();

    }

    public static void slaaSammen() {
        while (monitor.hentAntallHashMaps() > 1) {
            HashMap<String, Subsekvens> nyttHash = Monitor1.slaaSammen(monitor.taUtHashMap(), monitor.taUtHashMap());
            
            monitor.settInn(nyttHash);
        }
    }

    private static void skrivUtVanligste(Monitor1 monitor) {
        HashMap<String, Subsekvens> hash = monitor.hentRegister().get(0);
        Subsekvens flest = null;
        boolean sjekk = true;

        for (String key : hash.keySet()) {
            if (sjekk) {
                flest = hash.get(key);
                sjekk = false;
            } else {
                if (hash.get(key).hentAntall() > flest.hentAntall()) {
                    flest = hash.get(key);
                }
            }
        }

        System.out.println(flest);
    }


}
