import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

public class Oblig5Del1 {

    private static SubsekvensRegister reg = new SubsekvensRegister();
    public static void main(String[] args) throws FileNotFoundException {
        String path = args[0];
        lagNyttReg(path);
        slaaSammen();

        skrivUtVanligste(reg);
    }

    private static void lagNyttReg(String path) throws FileNotFoundException{
        File nyFil = new File(path);
        Scanner sc;
        try {
            sc = new Scanner(nyFil);
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException();
        }

        String linje;
        path = path.replace("metadata.csv", "");

        while (sc.hasNextLine()) {
            linje = sc.nextLine();

            HashMap<String, Subsekvens> hash = SubsekvensRegister.lesFraFil(path + linje);
            reg.settInn(hash);
        }
        sc.close();

    }

    public static void slaaSammen() {
        while (reg.hentAntallHashMaps() > 1) {
            HashMap<String, Subsekvens> nyttHash = SubsekvensRegister.slaaSammen(reg.taUtHashMap(), reg.taUtHashMap());
            
            reg.settInn(nyttHash);
        }
    }

    private static void skrivUtVanligste(SubsekvensRegister reg) {
        Subsekvens flest = null;
        boolean sjekk = true;

        for (String key : reg.hentRegister().get(0).keySet()) {
            if (sjekk) {
                flest = reg.hentRegister().get(0).get(key);
                sjekk = false;
            } else {
                if (reg.hentRegister().get(0).get(key).hentAntall() > flest.hentAntall()) {
                    flest = reg.hentRegister().get(0).get(key);
                }
            }
        }

        System.out.println(flest);
    }


}
