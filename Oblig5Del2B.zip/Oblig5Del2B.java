import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;

public class Oblig5Del2B {
    // private static Monitor2 monitor = new Monitor2(); // denne var riktig fra start
    private static Monitor2 monitor = new Monitor2();
    private final static int FLETTETRADER = 8;
    public static void main(String[] args) throws FileNotFoundException, InterruptedException {
        String path = args[0];
        lagNyttReg(path);
        slaaSammen();

        skrivUtVanligste(monitor);
    }

    private static void lagNyttReg(String path) throws FileNotFoundException, InterruptedException{
        File nyFil = new File(path);
        Scanner sc;
        try {
            sc = new Scanner(nyFil);
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException();
        }
        
        String nyPath = path.replace("metadata.csv", "");
        File fil = new File(nyPath);
        int lesbareFiler = fil.list().length - 1;
        CountDownLatch leseBarriere = new CountDownLatch(lesbareFiler);
        CountDownLatch fletteBarriere = new CountDownLatch(FLETTETRADER);

        // monitor = new Monitor2(lesbareFiler); // mulig denne ikke funker, i så fall gjør som jeg hadde fra starten
        String linje;
        path = path.replace("metadata.csv", "");

        while (sc.hasNextLine()) {
            linje = sc.nextLine();

            Runnable lesetrad = new LeseTrad(path + linje, monitor, leseBarriere);
            Thread trad = new Thread(lesetrad);
            trad.start();          
        }

        leseBarriere.await();
        System.out.println("Ferdig med leseBarriere");
        sc.close();

        int resterendeFlettinger = lesbareFiler - 1;

        for (int i = 0; i < FLETTETRADER; i++) {
            Runnable flettetrad = new FletteTrad(monitor, fletteBarriere, resterendeFlettinger); //mulig siste parameter må bort
            Thread trad = new Thread(flettetrad);
            trad.start();
            // if (monitor.hentStatus()) {
            //     break;
            // }

            resterendeFlettinger--; //mulig denne må bort
        }

        fletteBarriere.await();
        System.out.println("Ferdig med fletteBarriere");
    }

    public static void slaaSammen() throws InterruptedException {
        while (monitor.hentAntallHashMaps() > 1) {
            HashMap<String, Subsekvens> nyttHash = Monitor2.slaaSammen(monitor.taUtHashMap(), monitor.taUtHashMap());
            
            monitor.settInn(nyttHash);
        }
    }

    private static void skrivUtVanligste(Monitor2 monitor) {
        HashMap<String, Subsekvens> hash = monitor.hentRegister().get(0);
        Subsekvens flest = null;
        boolean sjekk = true;

        for (String key : hash.keySet()) {
            if (sjekk) {
                flest = hash.get(key);
                sjekk = false;
            } else {
                if (hash.get(key).hentAntall() > flest.hentAntall()) {
                    flest = hash.get(key);
                }
            }
        }

        System.out.println(flest);
    }


}
